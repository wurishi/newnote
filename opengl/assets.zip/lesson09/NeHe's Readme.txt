OpenGL Tutorial #9.

-Project Name: Jeff Molofee's OpenGL Tutorial

-Project Description: Creating Moving Scenes With Blended Textures.

-Authors Name: Jeff Molofee (aka NeHe)

-Authors Web Site: www.demonews.com/hosted/nehe

-COPYRIGHT AND DISCLAIMER: (c)1999 Jeff Molofee

	If you plan to put this program on your web page or a cdrom of
	any sort, let me know via email, I'm curious to see where
	it ends up :)

        If you use the code for your own projects please give me credit,
        or mention my web site somewhere in your program or it's docs.

If you've found this sourcecode useful, and would like to thank me, send
me a postcard, or anything else you think I may enjoy to:

		    Jeff Molofee
		    #37 Greenbrier Crescent
		    St.Albert, Alberta
		    T8N 1A2, Canada
