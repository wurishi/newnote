Keys which are being used are:

Cursor Keys : Move Camera
+/-         : Increase/Decrease Simulation TimeStep
F1          : Fullscreen On/Off
F2          : Hook Camera to Ball
F3          : Sound On/Off
