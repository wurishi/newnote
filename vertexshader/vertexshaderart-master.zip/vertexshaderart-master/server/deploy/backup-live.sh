#!/bin/sh
DOCKER=vertexshaderart.com
bash scripts/backup-support.sh $DOCKER "$DOCKER:backup"



