#!/bin/sh
bash scripts/backup-support.sh "" ../.local/backup


