This folder holds settings-xxx.env which is the env version of settings-xxx.json


