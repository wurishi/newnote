﻿import '../imports/ui/vertexshaderart.js';
import * as routes from '../imports/routes.js';
import { g } from '../imports/globals.js';

routes.init({
  handleImageFiles: function() {},
});

g.IMAGE_PATH = "ihopethisdoesnotmatterontheclient";

