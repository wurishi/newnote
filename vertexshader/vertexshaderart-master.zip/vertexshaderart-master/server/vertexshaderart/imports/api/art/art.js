const art = new Mongo.Collection("art");

export {
  art as collection,
};

