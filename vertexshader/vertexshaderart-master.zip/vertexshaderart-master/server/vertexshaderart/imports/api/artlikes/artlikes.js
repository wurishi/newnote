const artLikes = new Mongo.Collection("artlikes");

export {
  artLikes as collection,
};

