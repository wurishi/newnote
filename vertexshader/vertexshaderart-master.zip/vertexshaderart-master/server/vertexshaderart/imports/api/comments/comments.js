const comments = new Mongo.Collection("comments");

export {
  comments as collection,
};

