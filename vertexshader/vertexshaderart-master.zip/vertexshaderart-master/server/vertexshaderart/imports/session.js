const s = {
  CURRENTLY_SHARING: "currentlySharing",
  CURRENTLY_LOGGING_IN: "currentlyLoggingIn",
  EMBED: "embed",
  PENDING_LIKE: "pendingLike",
  ART_OWNER_ID: "artOwnerId",
  ART_NAME: "artName",
  ART_OWNER_NAME: "artOwnerName",
  HELP_DIALOG_URL: "helpDialogUrl",
  SAVE_VISIBILITY: "savevis",
};

export {
  s,
};

